import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adjust-treaty',
  templateUrl: './adjust-treaty.component.html',
  styles: [
  ]
})
export class AdjustTreatyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
