import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adjust-contract-show',
  templateUrl: './adjust-contract-show.component.html',
  styles: [
  ]
})
export class AdjustContractShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
