import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adjust-contract',
  templateUrl: './adjust-contract.component.html',
  styles: [
  ]
})
export class AdjustContractComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
