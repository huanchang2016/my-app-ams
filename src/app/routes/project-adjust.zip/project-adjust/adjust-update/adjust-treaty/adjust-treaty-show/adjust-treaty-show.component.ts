import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adjust-treaty-show',
  templateUrl: './adjust-treaty-show.component.html',
  styles: [
  ]
})
export class AdjustTreatyShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
